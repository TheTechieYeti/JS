console.log ("loading..")

function increasecount(id) {
    console.log ("is this working?")
    var element = document.querySelector( id );
    element.innerText ++;
}